package com.shinobi.launcher

import android.Manifest
import android.annotation.SuppressLint
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.drawable.Drawable
import android.net.Uri
import android.os.Bundle
import android.util.Base64
import android.webkit.*
import androidx.webkit.WebViewAssetLoader
import org.json.JSONArray
import org.json.JSONObject
import java.io.ByteArrayOutputStream

class MainActivity : Activity() {
    private lateinit var web: WebView
    private var fileCb: ValueCallback<Array<Uri>>? = null
    private var pendingPerm: PermissionRequest? = null

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        web = WebView(this)
        setContentView(web)

        web.settings.apply {
            javaScriptEnabled = true
            domStorageEnabled = true          // localStorage + IndexedDB
            mediaPlaybackRequiresUserGesture = false
            allowFileAccess = false
        }

        val loader = WebViewAssetLoader.Builder()
            .addPathHandler("/assets/", WebViewAssetLoader.AssetsPathHandler(this))
            .build()

        web.webViewClient = object : WebViewClient() {
            override fun shouldInterceptRequest(v: WebView, r: WebResourceRequest): WebResourceResponse? =
                loader.shouldInterceptRequest(r.url)

            override fun shouldOverrideUrlLoading(v: WebView, r: WebResourceRequest): Boolean {
                if (r.url.host == "appassets.androidplatform.net") return false
                openExternal(r.url)
                return true
            }
        }

        web.webChromeClient = object : WebChromeClient() {
            override fun onShowFileChooser(
                w: WebView, cb: ValueCallback<Array<Uri>>, p: FileChooserParams
            ): Boolean {
                fileCb?.onReceiveValue(null)
                fileCb = cb
                return try {
                    startActivityForResult(p.createIntent(), 1); true
                } catch (e: Exception) { fileCb = null; false }
            }

            override fun onPermissionRequest(request: PermissionRequest) {
                runOnUiThread {
                    if (checkSelfPermission(Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED) {
                        request.grant(request.resources)
                    } else {
                        pendingPerm = request
                        requestPermissions(arrayOf(Manifest.permission.CAMERA), 2)
                    }
                }
            }
        }

        web.addJavascriptInterface(Bridge(), "Android")
        web.loadUrl("https://appassets.androidplatform.net/assets/index.html")
    }

    override fun onActivityResult(rc: Int, res: Int, data: Intent?) {
        if (rc == 1) {
            fileCb?.onReceiveValue(WebChromeClient.FileChooserParams.parseResult(res, data))
            fileCb = null
        }
    }

    override fun onRequestPermissionsResult(rc: Int, perms: Array<out String>, results: IntArray) {
        if (rc == 2) {
            val ok = results.isNotEmpty() && results[0] == PackageManager.PERMISSION_GRANTED
            pendingPerm?.let { if (ok) it.grant(it.resources) else it.deny() }
            pendingPerm = null
        }
    }

    // A launcher should stay on the home screen when Back is pressed.
    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {}

    private fun openExternal(uri: Uri) {
        try { startActivity(Intent(Intent.ACTION_VIEW, uri).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) }
        catch (e: Exception) { }
    }

    private fun iconB64(d: Drawable): String {
        val bmp = Bitmap.createBitmap(96, 96, Bitmap.Config.ARGB_8888)
        d.setBounds(0, 0, 96, 96); d.draw(Canvas(bmp))
        val s = ByteArrayOutputStream()
        bmp.compress(Bitmap.CompressFormat.PNG, 100, s)
        return Base64.encodeToString(s.toByteArray(), Base64.NO_WRAP)
    }

    inner class Bridge {
        @JavascriptInterface
        fun getApps(): String {
            val pm = packageManager
            val q = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
            val arr = JSONArray()
            pm.queryIntentActivities(q, 0)
                .sortedBy { it.loadLabel(pm).toString().lowercase() }
                .forEach { ri ->
                    if (ri.activityInfo.packageName == packageName) return@forEach
                    arr.put(JSONObject().apply {
                        put("n", ri.loadLabel(pm).toString())
                        put("p", ri.activityInfo.packageName)
                        put("i", iconB64(ri.loadIcon(pm)))
                    })
                }
            return arr.toString()
        }

        @JavascriptInterface
        fun launch(pkg: String) {
            packageManager.getLaunchIntentForPackage(pkg)?.let { startActivity(it) }
        }

        @JavascriptInterface
        fun openUrl(u: String) { openExternal(Uri.parse(u)) }
    }
}
