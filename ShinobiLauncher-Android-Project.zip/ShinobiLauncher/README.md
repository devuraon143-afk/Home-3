# Shinobi Launcher (Android)

1. Install Android Studio (latest), then File > Open > select this ShinobiLauncher folder.
2. Let Gradle sync (accept the update prompt if it offers newer plugin versions).
3. Build > Build Bundle(s) / APK(s) > Build APK(s).
4. APK: app/build/outputs/apk/debug/app-debug.apk. Copy it to your phone and install it
   (allow "Install unknown apps" when asked).
5. Press the Home button and choose Shinobi Launcher > Always, or go to
   Settings > Apps > Default apps > Home app.

The launcher UI lives in app/src/main/assets/index.html. The "All Apps" drawer
shows your real installed apps; tap one to launch it.

## Build the APK on GitHub (no Android Studio needed)
1. Create a new GitHub repo and upload all files from this folder (keep the .github folder).
2. Open the repo > Actions tab > "Build APK" (it runs automatically on every push to main,
   or press "Run workflow").
3. When the run turns green, open it and download **shinobi-launcher-apk** from Artifacts.
4. Unzip it, install app-debug.apk on your phone.
